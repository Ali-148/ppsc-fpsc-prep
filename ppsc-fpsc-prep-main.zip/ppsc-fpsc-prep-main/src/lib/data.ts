// Types
export interface User {
  id: string;
  email: string;
  name: string;
  role: 'admin' | 'user';
}

export interface Book {
  id: string;
  title: string;
  description: string;
  category: 'PPSC' | 'FPSC';
  pdfUrl: string;
  uploadedAt: string;
}

export interface Option {
  id: string;
  text: string;
  isCorrect: boolean;
}

export interface Question {
  id: string;
  text: string;
  options: Option[];
}

export interface Quiz {
  id: string;
  title: string;
  category: 'PPSC' | 'FPSC';
  questions: Question[];
  createdAt: string;
}

export interface QuizResult {
  id: string;
  quizId: string;
  userId: string;
  score: number;
  totalQuestions: number;
  answers: Record<string, string>;
  completedAt: string;
}

// Dummy Data
export const dummyBooks: Book[] = [
  {
    id: '1',
    title: 'PPSC General Knowledge Guide 2024',
    description: 'Comprehensive guide covering all aspects of General Knowledge for PPSC exams including Pakistan Studies, Current Affairs, and World Geography.',
    category: 'PPSC',
    pdfUrl: '#',
    uploadedAt: '2024-01-15',
  },
  {
    id: '2',
    title: 'FPSC CSS Preparation Notes',
    description: 'Complete notes for CSS examination covering English Essay, Current Affairs, Pakistan Affairs, and Islamic Studies.',
    category: 'FPSC',
    pdfUrl: '#',
    uploadedAt: '2024-01-20',
  },
  {
    id: '3',
    title: 'Punjab History & Culture',
    description: 'Detailed notes on Punjab history, culture, and heritage for PPSC provincial exams.',
    category: 'PPSC',
    pdfUrl: '#',
    uploadedAt: '2024-02-01',
  },
  {
    id: '4',
    title: 'FPSC Interview Preparation',
    description: 'Guide for FPSC interview preparation with common questions and expert tips.',
    category: 'FPSC',
    pdfUrl: '#',
    uploadedAt: '2024-02-10',
  },
];

export const dummyQuizzes: Quiz[] = [
  {
    id: '1',
    title: 'PPSC General Knowledge',
    category: 'PPSC',
    createdAt: '2024-01-10',
    questions: [
      {
        id: 'q1',
        text: 'What is the capital of Pakistan?',
        options: [
          { id: 'q1o1', text: 'Islamabad', isCorrect: true },
          { id: 'q1o2', text: 'Lahore', isCorrect: false },
          { id: 'q1o3', text: 'Karachi', isCorrect: false },
          { id: 'q1o4', text: 'Peshawar', isCorrect: false },
        ],
      },
      {
        id: 'q2',
        text: 'Who is the founder of Pakistan?',
        options: [
          { id: 'q2o1', text: 'Allama Iqbal', isCorrect: false },
          { id: 'q2o2', text: 'Liaquat Ali Khan', isCorrect: false },
          { id: 'q2o3', text: 'Quaid-e-Azam Muhammad Ali Jinnah', isCorrect: true },
          { id: 'q2o4', text: 'Sir Syed Ahmed Khan', isCorrect: false },
        ],
      },
      {
        id: 'q3',
        text: 'Pakistan came into being in?',
        options: [
          { id: 'q3o1', text: '1945', isCorrect: false },
          { id: 'q3o2', text: '1946', isCorrect: false },
          { id: 'q3o3', text: '1947', isCorrect: true },
          { id: 'q3o4', text: '1948', isCorrect: false },
        ],
      },
    ],
  },
  {
    id: '2',
    title: 'FPSC Current Affairs',
    category: 'FPSC',
    createdAt: '2024-01-15',
    questions: [
      {
        id: 'q4',
        text: 'Which is the largest province of Pakistan by area?',
        options: [
          { id: 'q4o1', text: 'Punjab', isCorrect: false },
          { id: 'q4o2', text: 'Sindh', isCorrect: false },
          { id: 'q4o3', text: 'Balochistan', isCorrect: true },
          { id: 'q4o4', text: 'KPK', isCorrect: false },
        ],
      },
      {
        id: 'q5',
        text: 'What is the national language of Pakistan?',
        options: [
          { id: 'q5o1', text: 'English', isCorrect: false },
          { id: 'q5o2', text: 'Urdu', isCorrect: true },
          { id: 'q5o3', text: 'Punjabi', isCorrect: false },
          { id: 'q5o4', text: 'Sindhi', isCorrect: false },
        ],
      },
      {
        id: 'q6',
        text: 'Which river is the longest in Pakistan?',
        options: [
          { id: 'q6o1', text: 'Indus River', isCorrect: true },
          { id: 'q6o2', text: 'Jhelum River', isCorrect: false },
          { id: 'q6o3', text: 'Chenab River', isCorrect: false },
          { id: 'q6o4', text: 'Ravi River', isCorrect: false },
        ],
      },
    ],
  },
  {
    id: '3',
    title: 'PPSC Pakistan Studies',
    category: 'PPSC',
    createdAt: '2024-01-20',
    questions: [
      {
        id: 'q7',
        text: 'When was the first constitution of Pakistan adopted?',
        options: [
          { id: 'q7o1', text: '1947', isCorrect: false },
          { id: 'q7o2', text: '1956', isCorrect: true },
          { id: 'q7o3', text: '1962', isCorrect: false },
          { id: 'q7o4', text: '1973', isCorrect: false },
        ],
      },
      {
        id: 'q8',
        text: 'Who was the first Prime Minister of Pakistan?',
        options: [
          { id: 'q8o1', text: 'Quaid-e-Azam', isCorrect: false },
          { id: 'q8o2', text: 'Liaquat Ali Khan', isCorrect: true },
          { id: 'q8o3', text: 'Khawaja Nazimuddin', isCorrect: false },
          { id: 'q8o4', text: 'Hussain Shaheed Suhrawardy', isCorrect: false },
        ],
      },
    ],
  },
];

// Default admin user
export const defaultAdmin: User = {
  id: 'admin-1',
  email: 'admin@ppscfpsc.com',
  name: 'Admin User',
  role: 'admin',
};