import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { Book, Quiz, QuizResult, dummyBooks, dummyQuizzes } from '@/lib/data';

interface DataContextType {
  books: Book[];
  quizzes: Quiz[];
  results: QuizResult[];
  addBook: (book: Omit<Book, 'id' | 'uploadedAt'>) => void;
  deleteBook: (id: string) => void;
  addQuiz: (quiz: Omit<Quiz, 'id' | 'createdAt'>) => void;
  updateQuiz: (id: string, quiz: Partial<Quiz>) => void;
  deleteQuiz: (id: string) => void;
  submitQuizResult: (result: Omit<QuizResult, 'id' | 'completedAt'>) => void;
  getUserResults: (userId: string) => QuizResult[];
  hasAttemptedQuiz: (userId: string, quizId: string) => boolean;
}

const DataContext = createContext<DataContextType | undefined>(undefined);

export const useData = () => {
  const context = useContext(DataContext);
  if (!context) {
    throw new Error('useData must be used within a DataProvider');
  }
  return context;
};

interface DataProviderProps {
  children: ReactNode;
}

export const DataProvider: React.FC<DataProviderProps> = ({ children }) => {
  const [books, setBooks] = useState<Book[]>([]);
  const [quizzes, setQuizzes] = useState<Quiz[]>([]);
  const [results, setResults] = useState<QuizResult[]>([]);

  useEffect(() => {
    // Load from localStorage or use dummy data
    const storedBooks = localStorage.getItem('books');
    const storedQuizzes = localStorage.getItem('quizzes');
    const storedResults = localStorage.getItem('quizResults');

    setBooks(storedBooks ? JSON.parse(storedBooks) : dummyBooks);
    setQuizzes(storedQuizzes ? JSON.parse(storedQuizzes) : dummyQuizzes);
    setResults(storedResults ? JSON.parse(storedResults) : []);
  }, []);

  const saveBooks = (newBooks: Book[]) => {
    setBooks(newBooks);
    localStorage.setItem('books', JSON.stringify(newBooks));
  };

  const saveQuizzes = (newQuizzes: Quiz[]) => {
    setQuizzes(newQuizzes);
    localStorage.setItem('quizzes', JSON.stringify(newQuizzes));
  };

  const saveResults = (newResults: QuizResult[]) => {
    setResults(newResults);
    localStorage.setItem('quizResults', JSON.stringify(newResults));
  };

  const addBook = (book: Omit<Book, 'id' | 'uploadedAt'>) => {
    const newBook: Book = {
      ...book,
      id: `book-${Date.now()}`,
      uploadedAt: new Date().toISOString().split('T')[0],
    };
    saveBooks([...books, newBook]);
  };

  const deleteBook = (id: string) => {
    saveBooks(books.filter(b => b.id !== id));
  };

  const addQuiz = (quiz: Omit<Quiz, 'id' | 'createdAt'>) => {
    const newQuiz: Quiz = {
      ...quiz,
      id: `quiz-${Date.now()}`,
      createdAt: new Date().toISOString().split('T')[0],
    };
    saveQuizzes([...quizzes, newQuiz]);
  };

  const updateQuiz = (id: string, updates: Partial<Quiz>) => {
    saveQuizzes(quizzes.map(q => q.id === id ? { ...q, ...updates } : q));
  };

  const deleteQuiz = (id: string) => {
    saveQuizzes(quizzes.filter(q => q.id !== id));
  };

  const submitQuizResult = (result: Omit<QuizResult, 'id' | 'completedAt'>) => {
    const newResult: QuizResult = {
      ...result,
      id: `result-${Date.now()}`,
      completedAt: new Date().toISOString(),
    };
    saveResults([...results, newResult]);
  };

  const getUserResults = (userId: string) => {
    return results.filter(r => r.userId === userId);
  };

  const hasAttemptedQuiz = (userId: string, quizId: string) => {
    return results.some(r => r.userId === userId && r.quizId === quizId);
  };

  return (
    <DataContext.Provider value={{
      books,
      quizzes,
      results,
      addBook,
      deleteBook,
      addQuiz,
      updateQuiz,
      deleteQuiz,
      submitQuizResult,
      getUserResults,
      hasAttemptedQuiz,
    }}>
      {children}
    </DataContext.Provider>
  );
};