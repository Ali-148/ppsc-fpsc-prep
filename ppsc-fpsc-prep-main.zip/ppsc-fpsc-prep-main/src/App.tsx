import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AuthProvider } from "@/contexts/AuthContext";
import { DataProvider } from "@/contexts/DataContext";
import ProtectedRoute from "@/components/ProtectedRoute";

// Public Pages
import Index from "./pages/Index";
import Login from "./pages/Login";
import Register from "./pages/Register";
import NotFound from "./pages/NotFound";

// User Pages
import Dashboard from "./pages/Dashboard";
import Books from "./pages/Books";
import Quizzes from "./pages/Quizzes";
import AttemptQuiz from "./pages/AttemptQuiz";
import QuizResult from "./pages/QuizResult";

// Admin Pages
import AdminDashboard from "./pages/admin/AdminDashboard";
import UploadBook from "./pages/admin/UploadBook";
import CreateQuiz from "./pages/admin/CreateQuiz";
import ManageQuizzes from "./pages/admin/ManageQuizzes";
import EditQuiz from "./pages/admin/EditQuiz";
import ManageBooks from "./pages/admin/ManageBooks";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <AuthProvider>
      <DataProvider>
        <TooltipProvider>
          <Toaster />
          <Sonner />
          <BrowserRouter>
            <Routes>
              {/* Public Routes */}
              <Route path="/" element={<Index />} />
              <Route path="/login" element={<Login />} />
              <Route path="/register" element={<Register />} />

              {/* Protected User Routes */}
              <Route path="/dashboard" element={
                <ProtectedRoute>
                  <Dashboard />
                </ProtectedRoute>
              } />
              <Route path="/books" element={
                <ProtectedRoute>
                  <Books />
                </ProtectedRoute>
              } />
              <Route path="/quizzes" element={
                <ProtectedRoute>
                  <Quizzes />
                </ProtectedRoute>
              } />
              <Route path="/quiz/:id" element={
                <ProtectedRoute>
                  <AttemptQuiz />
                </ProtectedRoute>
              } />
              <Route path="/quiz/:id/result" element={
                <ProtectedRoute>
                  <QuizResult />
                </ProtectedRoute>
              } />

              {/* Protected Admin Routes */}
              <Route path="/admin" element={
                <ProtectedRoute requireAdmin>
                  <AdminDashboard />
                </ProtectedRoute>
              } />
              <Route path="/admin/books/upload" element={
                <ProtectedRoute requireAdmin>
                  <UploadBook />
                </ProtectedRoute>
              } />
              <Route path="/admin/books" element={
                <ProtectedRoute requireAdmin>
                  <ManageBooks />
                </ProtectedRoute>
              } />
              <Route path="/admin/quizzes" element={
                <ProtectedRoute requireAdmin>
                  <ManageQuizzes />
                </ProtectedRoute>
              } />
              <Route path="/admin/quizzes/create" element={
                <ProtectedRoute requireAdmin>
                  <CreateQuiz />
                </ProtectedRoute>
              } />
              <Route path="/admin/quizzes/:id/edit" element={
                <ProtectedRoute requireAdmin>
                  <EditQuiz />
                </ProtectedRoute>
              } />

              {/* Catch-all */}
              <Route path="*" element={<NotFound />} />
            </Routes>
          </BrowserRouter>
        </TooltipProvider>
      </DataProvider>
    </AuthProvider>
  </QueryClientProvider>
);

export default App;