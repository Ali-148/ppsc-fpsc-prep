import { Link } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { useData } from '@/contexts/DataContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import Layout from '@/components/layout/Layout';
import { BookOpen, GraduationCap, Trophy, ArrowRight, CheckCircle, Clock } from 'lucide-react';

const Dashboard = () => {
  const { user } = useAuth();
  const { books, quizzes, getUserResults } = useData();

  const userResults = user ? getUserResults(user.id) : [];
  const completedQuizzes = userResults.length;
  const averageScore = userResults.length > 0
    ? Math.round(userResults.reduce((acc, r) => acc + (r.score / r.totalQuestions) * 100, 0) / userResults.length)
    : 0;

  const recentResults = userResults.slice(-3).reverse();

  return (
    <Layout>
      <div className="container mx-auto px-4 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2">
            Welcome back, {user?.name}! 👋
          </h1>
          <p className="text-muted-foreground">
            Continue your exam preparation journey. Here's your progress overview.
          </p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Quizzes Completed
              </CardTitle>
              <CheckCircle className="w-5 h-5 text-primary" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{completedQuizzes}</div>
              <p className="text-sm text-muted-foreground">
                out of {quizzes.length} available
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Average Score
              </CardTitle>
              <Trophy className="w-5 h-5 text-accent" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{averageScore}%</div>
              <p className="text-sm text-muted-foreground">
                across all attempts
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Study Materials
              </CardTitle>
              <BookOpen className="w-5 h-5 text-secondary" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{books.length}</div>
              <p className="text-sm text-muted-foreground">
                books & notes available
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mb-2">
                <GraduationCap className="w-6 h-6 text-primary" />
              </div>
              <CardTitle>Practice Quizzes</CardTitle>
              <CardDescription>
                Test your knowledge with our comprehensive quiz collection for PPSC & FPSC exams.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button asChild>
                <Link to="/quizzes">
                  Browse Quizzes
                  <ArrowRight className="ml-2 w-4 h-4" />
                </Link>
              </Button>
            </CardContent>
          </Card>

          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <div className="w-12 h-12 rounded-lg bg-secondary/10 flex items-center justify-center mb-2">
                <BookOpen className="w-6 h-6 text-secondary" />
              </div>
              <CardTitle>Study Materials</CardTitle>
              <CardDescription>
                Access books, notes, and previous year papers to enhance your preparation.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button variant="secondary" asChild>
                <Link to="/books">
                  View Books
                  <ArrowRight className="ml-2 w-4 h-4" />
                </Link>
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Recent Activity */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Clock className="w-5 h-5" />
              Recent Quiz Results
            </CardTitle>
          </CardHeader>
          <CardContent>
            {recentResults.length > 0 ? (
              <div className="space-y-4">
                {recentResults.map((result) => {
                  const quiz = quizzes.find(q => q.id === result.quizId);
                  const percentage = Math.round((result.score / result.totalQuestions) * 100);
                  return (
                    <div
                      key={result.id}
                      className="flex items-center justify-between p-4 bg-muted/50 rounded-lg"
                    >
                      <div>
                        <p className="font-medium">{quiz?.title || 'Unknown Quiz'}</p>
                        <p className="text-sm text-muted-foreground">
                          {new Date(result.completedAt).toLocaleDateString()}
                        </p>
                      </div>
                      <div className="text-right">
                        <p className={`text-lg font-bold ${percentage >= 70 ? 'text-primary' : percentage >= 50 ? 'text-accent' : 'text-destructive'}`}>
                          {percentage}%
                        </p>
                        <p className="text-sm text-muted-foreground">
                          {result.score}/{result.totalQuestions}
                        </p>
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="text-center py-8 text-muted-foreground">
                <GraduationCap className="w-12 h-12 mx-auto mb-4 opacity-50" />
                <p>You haven't attempted any quizzes yet.</p>
                <Button variant="link" asChild className="mt-2">
                  <Link to="/quizzes">Start your first quiz</Link>
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
};

export default Dashboard;