import { useState, useEffect } from 'react';
import { useNavigate, useParams, Link } from 'react-router-dom';
import { useData } from '@/contexts/DataContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import Layout from '@/components/layout/Layout';
import { Plus, Trash2, ArrowLeft, Save } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { Question } from '@/lib/data';

const EditQuiz = () => {
  const { id } = useParams<{ id: string }>();
  const { quizzes, updateQuiz } = useData();
  const navigate = useNavigate();
  const { toast } = useToast();

  const quiz = quizzes.find(q => q.id === id);

  const [title, setTitle] = useState('');
  const [category, setCategory] = useState<'PPSC' | 'FPSC'>('PPSC');
  const [questions, setQuestions] = useState<Question[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (quiz) {
      setTitle(quiz.title);
      setCategory(quiz.category);
      setQuestions([...quiz.questions]);
    }
  }, [quiz]);

  if (!quiz) {
    return (
      <Layout>
        <div className="container mx-auto px-4 py-16 text-center">
          <h1 className="text-2xl font-bold mb-2">Quiz Not Found</h1>
          <p className="text-muted-foreground mb-4">The quiz you're looking for doesn't exist.</p>
          <Button onClick={() => navigate('/admin/quizzes')}>Back to Quizzes</Button>
        </div>
      </Layout>
    );
  }

  const addQuestion = () => {
    const newQuestion: Question = {
      id: `q-${Date.now()}`,
      text: '',
      options: [
        { id: `o-${Date.now()}-1`, text: '', isCorrect: true },
        { id: `o-${Date.now()}-2`, text: '', isCorrect: false },
        { id: `o-${Date.now()}-3`, text: '', isCorrect: false },
        { id: `o-${Date.now()}-4`, text: '', isCorrect: false },
      ],
    };
    setQuestions([...questions, newQuestion]);
  };

  const removeQuestion = (questionId: string) => {
    setQuestions(questions.filter(q => q.id !== questionId));
  };

  const updateQuestionText = (questionId: string, text: string) => {
    setQuestions(questions.map(q => 
      q.id === questionId ? { ...q, text } : q
    ));
  };

  const updateOptionText = (questionId: string, optionId: string, text: string) => {
    setQuestions(questions.map(q => 
      q.id === questionId
        ? {
            ...q,
            options: q.options.map(o => 
              o.id === optionId ? { ...o, text } : o
            ),
          }
        : q
    ));
  };

  const setCorrectOption = (questionId: string, optionId: string) => {
    setQuestions(questions.map(q => 
      q.id === questionId
        ? {
            ...q,
            options: q.options.map(o => ({
              ...o,
              isCorrect: o.id === optionId,
            })),
          }
        : q
    ));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!title) {
      toast({
        title: 'Missing title',
        description: 'Please enter a quiz title.',
        variant: 'destructive',
      });
      return;
    }

    if (questions.length === 0) {
      toast({
        title: 'No questions',
        description: 'Please add at least one question.',
        variant: 'destructive',
      });
      return;
    }

    setIsSubmitting(true);

    updateQuiz(id!, {
      title,
      category,
      questions,
    });

    toast({
      title: 'Quiz updated!',
      description: 'The quiz has been successfully updated.',
    });

    navigate('/admin/quizzes');
  };

  return (
    <Layout>
      <div className="container mx-auto px-4 py-8 max-w-3xl">
        <div className="mb-6">
          <Link to="/admin/quizzes" className="inline-flex items-center text-muted-foreground hover:text-foreground mb-4">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Manage Quizzes
          </Link>
          <h1 className="text-3xl font-bold text-foreground">Edit Quiz</h1>
          <p className="text-muted-foreground">Update quiz details and questions.</p>
        </div>

        <form onSubmit={handleSubmit}>
          <Card className="mb-6">
            <CardHeader>
              <CardTitle>Quiz Details</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="title">Quiz Title *</Label>
                <Input
                  id="title"
                  placeholder="Enter quiz title"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="category">Category *</Label>
                <Select value={category} onValueChange={(v) => setCategory(v as 'PPSC' | 'FPSC')}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select category" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="PPSC">PPSC</SelectItem>
                    <SelectItem value="FPSC">FPSC</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          <div className="space-y-4 mb-6">
            {questions.map((question, qIndex) => (
              <Card key={question.id}>
                <CardHeader className="flex flex-row items-start justify-between">
                  <CardTitle className="text-lg">Question {qIndex + 1}</CardTitle>
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    onClick={() => removeQuestion(question.id)}
                    className="text-destructive hover:text-destructive"
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label>Question Text *</Label>
                    <Input
                      placeholder="Enter question"
                      value={question.text}
                      onChange={(e) => updateQuestionText(question.id, e.target.value)}
                    />
                  </div>

                  <div className="space-y-3">
                    <Label>Options (select correct answer)</Label>
                    {question.options.map((option, oIndex) => (
                      <div key={option.id} className="flex items-center gap-3">
                        <input
                          type="radio"
                          name={`correct-${question.id}`}
                          checked={option.isCorrect}
                          onChange={() => setCorrectOption(question.id, option.id)}
                          className="w-4 h-4 text-primary"
                        />
                        <Input
                          placeholder={`Option ${oIndex + 1}`}
                          value={option.text}
                          onChange={(e) => updateOptionText(question.id, option.id, e.target.value)}
                          className={option.isCorrect ? 'border-primary' : ''}
                        />
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          <Button type="button" variant="outline" onClick={addQuestion} className="w-full mb-6">
            <Plus className="w-4 h-4 mr-2" />
            Add Question
          </Button>

          <div className="flex gap-4">
            <Button type="button" variant="outline" onClick={() => navigate('/admin/quizzes')}>
              Cancel
            </Button>
            <Button type="submit" disabled={isSubmitting}>
              <Save className="w-4 h-4 mr-2" />
              {isSubmitting ? 'Saving...' : 'Save Changes'}
            </Button>
          </div>
        </form>
      </div>
    </Layout>
  );
};

export default EditQuiz;