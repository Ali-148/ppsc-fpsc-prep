import { useParams, useNavigate, Link } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { useData } from '@/contexts/DataContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import Layout from '@/components/layout/Layout';
import { Trophy, CheckCircle, XCircle, ArrowLeft, RotateCcw } from 'lucide-react';

const QuizResult = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { user } = useAuth();
  const { quizzes, getUserResults } = useData();

  const quiz = quizzes.find(q => q.id === id);
  const userResults = user ? getUserResults(user.id) : [];
  const result = userResults.find(r => r.quizId === id);

  if (!quiz || !result) {
    return (
      <Layout>
        <div className="container mx-auto px-4 py-16 text-center">
          <h1 className="text-2xl font-bold mb-2">Result Not Found</h1>
          <p className="text-muted-foreground mb-4">You haven't attempted this quiz yet.</p>
          <Button onClick={() => navigate('/quizzes')}>Back to Quizzes</Button>
        </div>
      </Layout>
    );
  }

  const percentage = Math.round((result.score / result.totalQuestions) * 100);
  const isPassed = percentage >= 50;

  const getScoreColor = () => {
    if (percentage >= 80) return 'text-primary';
    if (percentage >= 50) return 'text-accent';
    return 'text-destructive';
  };

  const getScoreMessage = () => {
    if (percentage >= 80) return 'Excellent! Outstanding performance!';
    if (percentage >= 70) return 'Great job! You did well!';
    if (percentage >= 50) return 'Good effort! Keep practicing!';
    return 'Keep learning! You can do better!';
  };

  return (
    <Layout>
      <div className="container mx-auto px-4 py-8 max-w-3xl">
        {/* Result Summary */}
        <Card className="mb-8 overflow-hidden">
          <div className={`h-2 ${isPassed ? 'bg-primary' : 'bg-destructive'}`} />
          <CardHeader className="text-center pb-2">
            <div className={`w-20 h-20 mx-auto rounded-full flex items-center justify-center mb-4 ${
              isPassed ? 'bg-primary/10' : 'bg-destructive/10'
            }`}>
              <Trophy className={`w-10 h-10 ${isPassed ? 'text-primary' : 'text-destructive'}`} />
            </div>
            <CardTitle className="text-2xl mb-2">{quiz.title}</CardTitle>
            <Badge variant={quiz.category === 'PPSC' ? 'default' : 'secondary'}>
              {quiz.category}
            </Badge>
          </CardHeader>
          <CardContent className="text-center">
            <p className={`text-6xl font-bold mb-2 ${getScoreColor()}`}>
              {percentage}%
            </p>
            <p className="text-xl text-muted-foreground mb-2">
              {result.score} out of {result.totalQuestions} correct
            </p>
            <p className="text-lg font-medium">{getScoreMessage()}</p>
            <p className="text-sm text-muted-foreground mt-2">
              Completed on {new Date(result.completedAt).toLocaleString()}
            </p>
          </CardContent>
        </Card>

        {/* Detailed Results */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Question Review</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {quiz.questions.map((question, index) => {
              const selectedOptionId = result.answers[question.id];
              const correctOption = question.options.find(o => o.isCorrect);
              const selectedOption = question.options.find(o => o.id === selectedOptionId);
              const isCorrect = selectedOptionId === correctOption?.id;

              return (
                <div key={question.id} className="border-b border-border pb-6 last:border-0 last:pb-0">
                  <div className="flex items-start gap-3 mb-4">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 ${
                      isCorrect ? 'bg-primary/10' : 'bg-destructive/10'
                    }`}>
                      {isCorrect ? (
                        <CheckCircle className="w-5 h-5 text-primary" />
                      ) : (
                        <XCircle className="w-5 h-5 text-destructive" />
                      )}
                    </div>
                    <div>
                      <p className="font-medium">Q{index + 1}: {question.text}</p>
                    </div>
                  </div>
                  <div className="ml-11 space-y-2">
                    <div className="flex items-center gap-2">
                      <span className="text-sm text-muted-foreground">Your answer:</span>
                      <span className={isCorrect ? 'text-primary font-medium' : 'text-destructive font-medium'}>
                        {selectedOption?.text || 'Not answered'}
                      </span>
                    </div>
                    {!isCorrect && (
                      <div className="flex items-center gap-2">
                        <span className="text-sm text-muted-foreground">Correct answer:</span>
                        <span className="text-primary font-medium">{correctOption?.text}</span>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </CardContent>
        </Card>

        {/* Actions */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button variant="outline" asChild>
            <Link to="/quizzes">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Quizzes
            </Link>
          </Button>
          <Button asChild>
            <Link to="/dashboard">
              <RotateCcw className="w-4 h-4 mr-2" />
              Go to Dashboard
            </Link>
          </Button>
        </div>
      </div>
    </Layout>
  );
};

export default QuizResult;