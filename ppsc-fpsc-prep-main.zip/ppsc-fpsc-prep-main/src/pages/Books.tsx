import { useState } from 'react';
import { useData } from '@/contexts/DataContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import Layout from '@/components/layout/Layout';
import { BookOpen, Download, Search, Filter } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

const Books = () => {
  const { books } = useData();
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<'all' | 'PPSC' | 'FPSC'>('all');
  const { toast } = useToast();

  const filteredBooks = books.filter(book => {
    const matchesSearch = book.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      book.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = categoryFilter === 'all' || book.category === categoryFilter;
    return matchesSearch && matchesCategory;
  });

  const handleDownload = (book: typeof books[0]) => {
    toast({
      title: 'Download Started',
      description: `Downloading "${book.title}"...`,
    });
    // In a real app, this would trigger actual file download
  };

  return (
    <Layout>
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2 flex items-center gap-3">
            <BookOpen className="w-8 h-8 text-primary" />
            Books & Notes
          </h1>
          <p className="text-muted-foreground">
            Download study materials and notes for your exam preparation.
          </p>
        </div>

        {/* Filters */}
        <div className="flex flex-col md:flex-row gap-4 mb-8">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Search books..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
          <div className="flex gap-2">
            <Button
              variant={categoryFilter === 'all' ? 'default' : 'outline'}
              onClick={() => setCategoryFilter('all')}
              size="sm"
            >
              <Filter className="w-4 h-4 mr-2" />
              All
            </Button>
            <Button
              variant={categoryFilter === 'PPSC' ? 'default' : 'outline'}
              onClick={() => setCategoryFilter('PPSC')}
              size="sm"
            >
              PPSC
            </Button>
            <Button
              variant={categoryFilter === 'FPSC' ? 'default' : 'outline'}
              onClick={() => setCategoryFilter('FPSC')}
              size="sm"
            >
              FPSC
            </Button>
          </div>
        </div>

        {/* Books Grid */}
        {filteredBooks.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredBooks.map((book) => (
              <Card key={book.id} className="flex flex-col hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex items-start justify-between gap-2">
                    <CardTitle className="text-lg leading-tight">{book.title}</CardTitle>
                    <Badge variant={book.category === 'PPSC' ? 'default' : 'secondary'}>
                      {book.category}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="flex-1">
                  <CardDescription className="text-base line-clamp-3">
                    {book.description}
                  </CardDescription>
                  <p className="text-sm text-muted-foreground mt-4">
                    Uploaded: {new Date(book.uploadedAt).toLocaleDateString()}
                  </p>
                </CardContent>
                <CardFooter>
                  <Button onClick={() => handleDownload(book)} className="w-full">
                    <Download className="w-4 h-4 mr-2" />
                    Download PDF
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        ) : (
          <div className="text-center py-16 text-muted-foreground">
            <BookOpen className="w-16 h-16 mx-auto mb-4 opacity-50" />
            <p className="text-lg">No books found matching your criteria.</p>
            <p className="text-sm">Try adjusting your search or filters.</p>
          </div>
        )}
      </div>
    </Layout>
  );
};

export default Books;