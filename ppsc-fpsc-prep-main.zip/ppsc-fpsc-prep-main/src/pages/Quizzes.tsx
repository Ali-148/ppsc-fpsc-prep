import { useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { useData } from '@/contexts/DataContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import Layout from '@/components/layout/Layout';
import { GraduationCap, Search, Filter, Play, CheckCircle, Clock } from 'lucide-react';

const Quizzes = () => {
  const { user } = useAuth();
  const { quizzes, hasAttemptedQuiz, getUserResults } = useData();
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<'all' | 'PPSC' | 'FPSC'>('all');

  const userResults = user ? getUserResults(user.id) : [];

  const filteredQuizzes = quizzes.filter(quiz => {
    const matchesSearch = quiz.title.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = categoryFilter === 'all' || quiz.category === categoryFilter;
    return matchesSearch && matchesCategory;
  });

  const getQuizResult = (quizId: string) => {
    return userResults.find(r => r.quizId === quizId);
  };

  return (
    <Layout>
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2 flex items-center gap-3">
            <GraduationCap className="w-8 h-8 text-primary" />
            Practice Quizzes
          </h1>
          <p className="text-muted-foreground">
            Test your knowledge with our comprehensive quiz collection.
          </p>
        </div>

        {/* Filters */}
        <div className="flex flex-col md:flex-row gap-4 mb-8">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Search quizzes..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
          <div className="flex gap-2">
            <Button
              variant={categoryFilter === 'all' ? 'default' : 'outline'}
              onClick={() => setCategoryFilter('all')}
              size="sm"
            >
              <Filter className="w-4 h-4 mr-2" />
              All
            </Button>
            <Button
              variant={categoryFilter === 'PPSC' ? 'default' : 'outline'}
              onClick={() => setCategoryFilter('PPSC')}
              size="sm"
            >
              PPSC
            </Button>
            <Button
              variant={categoryFilter === 'FPSC' ? 'default' : 'outline'}
              onClick={() => setCategoryFilter('FPSC')}
              size="sm"
            >
              FPSC
            </Button>
          </div>
        </div>

        {/* Quizzes Grid */}
        {filteredQuizzes.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredQuizzes.map((quiz) => {
              const attempted = user ? hasAttemptedQuiz(user.id, quiz.id) : false;
              const result = user ? getQuizResult(quiz.id) : null;
              const percentage = result ? Math.round((result.score / result.totalQuestions) * 100) : 0;

              return (
                <Card key={quiz.id} className="flex flex-col hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className="flex items-start justify-between gap-2">
                      <CardTitle className="text-lg leading-tight">{quiz.title}</CardTitle>
                      <Badge variant={quiz.category === 'PPSC' ? 'default' : 'secondary'}>
                        {quiz.category}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="flex-1">
                    <div className="flex items-center gap-4 text-sm text-muted-foreground">
                      <span className="flex items-center gap-1">
                        <Clock className="w-4 h-4" />
                        {quiz.questions.length} questions
                      </span>
                      {attempted && (
                        <span className="flex items-center gap-1 text-primary">
                          <CheckCircle className="w-4 h-4" />
                          Completed
                        </span>
                      )}
                    </div>
                    {result && (
                      <div className="mt-4 p-3 bg-muted/50 rounded-lg">
                        <p className="text-sm text-muted-foreground">Your Score:</p>
                        <p className={`text-2xl font-bold ${percentage >= 70 ? 'text-primary' : percentage >= 50 ? 'text-accent' : 'text-destructive'}`}>
                          {percentage}%
                          <span className="text-sm font-normal text-muted-foreground ml-2">
                            ({result.score}/{result.totalQuestions})
                          </span>
                        </p>
                      </div>
                    )}
                  </CardContent>
                  <CardFooter>
                    {attempted ? (
                      <Button variant="outline" asChild className="w-full">
                        <Link to={`/quiz/${quiz.id}/result`}>
                          View Result
                        </Link>
                      </Button>
                    ) : (
                      <Button asChild className="w-full">
                        <Link to={`/quiz/${quiz.id}`}>
                          <Play className="w-4 h-4 mr-2" />
                          Start Quiz
                        </Link>
                      </Button>
                    )}
                  </CardFooter>
                </Card>
              );
            })}
          </div>
        ) : (
          <div className="text-center py-16 text-muted-foreground">
            <GraduationCap className="w-16 h-16 mx-auto mb-4 opacity-50" />
            <p className="text-lg">No quizzes found matching your criteria.</p>
            <p className="text-sm">Try adjusting your search or filters.</p>
          </div>
        )}
      </div>
    </Layout>
  );
};

export default Quizzes;